# datacleaning-python

this .ipynb file is data cleaning and analysis using python
